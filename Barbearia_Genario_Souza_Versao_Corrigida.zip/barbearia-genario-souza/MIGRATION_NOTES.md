# Notas da migração independente

## Alterações nesta cópia

- Removida a configuração Vite gerenciada pelo Lovable e substituída pela configuração oficial do TanStack Start + Nitro + React.
- Removido o plugin Tailwind v4 do Vite e adotado Tailwind CSS 3.4 via PostCSS + Autoprefixer.
- Convertidos os tokens OKLCH para RGB e removidos `color-mix()` e diretivas exclusivas do Tailwind v4.
- Mantidas as classes utilitárias personalizadas e as animações usadas pelo aplicativo.
- Adicionado alvo de compilação Safari 15.3.
- Removido o broker de autenticação do preview/editor; sessões passam a usar o armazenamento local do navegador.
- Removido o envio de erros para hooks internos do editor.
- Mantidas as integrações e tabelas do Supabase sem alterações.
- Nenhum arquivo `.env` ou segredo foi incluído.

## Validação executada

A validação estática de manifestos, dependências, diretivas CSS, arquivos de configuração e imports relativos passou. Os imports `routeTree.gen` e `styles.css?url` são gerados/resolvidos pelo pipeline do TanStack/Vite.

## Validação ainda necessária

A instalação de dependências não foi concluída porque o registro npm não respondeu dentro do tempo limite deste ambiente. Portanto, ainda não foi possível executar `npm run build`, `npm test`, nem abrir a aplicação em um Safari/iPhone 7 real.

## Próximos comandos

```sh
npm install
npm run check
npm run build
npm test
npm run preview
```

Antes da implantação independente em Cloudflare, configure os secrets `SUPABASE_URL`, `SUPABASE_PUBLISHABLE_KEY` e `SUPABASE_SERVICE_ROLE_KEY` no ambiente do Worker. A chave `SUPABASE_SERVICE_ROLE_KEY` é confidencial e nunca deve ser enviada ao navegador ou incluída no repositório.
