# Barbearia Genario Souza

Aplicativo web de agendamento da Barbearia Genario Souza, construído com React, TanStack Start, Vite, Tailwind CSS 3.4 e Supabase.

## Requisitos

- Node.js 22 ou superior
- npm 10 ou superior

## Instalação local

```sh
npm install
cp .env.example .env
npm run dev
```

## Verificações

```sh
npm run check
npm run build
npm test
```

## Variáveis de ambiente do servidor

Configure no ambiente de hospedagem:

- `SUPABASE_URL`
- `SUPABASE_PUBLISHABLE_KEY`
- `SUPABASE_SERVICE_ROLE_KEY` — segredo exclusivo do servidor; nunca coloque em variáveis `VITE_*` nem no navegador.

O cliente público do Supabase atualmente usa a URL e a chave publishable já configuradas em `src/integrations/supabase/client.ts`. O arquivo `.env.example` documenta as variáveis necessárias para as funções de servidor e para uma futura migração do cliente público para configuração por ambiente.

## Hospedagem

O projeto usa Nitro com preset Cloudflare Module. Antes de publicar, configure os secrets e a implantação no provedor escolhido e valide a saída de produção. Não publique `.env` nem compartilhe a chave `SUPABASE_SERVICE_ROLE_KEY`.

## Compatibilidade

O CSS foi convertido para Tailwind CSS 3.4, com tokens RGB e sem sintaxe CSS Color 4 / OKLCH. A compilação JavaScript está configurada para Safari 15.3 como alvo conservador. A validação final ainda exige instalação de dependências, build de produção e teste real em Safari/iOS 15.
