/**
 * Use the browser's own persistent storage for Supabase sessions.
 * No editor iframe or external auth broker is required.
 */
export function browserAuthStorage() {
  if (typeof window === "undefined") return undefined;
  try {
    return window.localStorage;
  } catch {
    return undefined;
  }
}
