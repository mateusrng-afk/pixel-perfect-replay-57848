import type { Appointment, BarberBreak, BarberService, BusinessHour, BusyTime, Service } from "./types";

export const SLOT_STEP_MINUTES = 30;

export function timeToMinutes(time: string): number {
  const [h = 0, m = 0] = time.split(":").map(Number);
  return h * 60 + m;
}

export function minutesToTime(total: number): string {
  const h = Math.floor(total / 60);
  const m = total % 60;
  return `${String(h).padStart(2, "0")}:${String(m).padStart(2, "0")}`;
}

export function toDateKey(date: Date): string {
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, "0");
  const d = String(date.getDate()).padStart(2, "0");
  return `${y}-${m}-${d}`;
}

export function fromDateKey(key: string): Date {
  const [y = 1970, m = 1, d = 1] = key.split("-").map(Number);
  return new Date(y, m - 1, d);
}

export function totalPrice(services: Pick<Service, "price">[]): number {
  return services.reduce((sum, s) => sum + Number(s.price), 0);
}

export function totalDuration(services: Pick<Service, "duration_minutes">[]): number {
  return services.reduce((sum, s) => sum + Number(s.duration_minutes), 0);
}

export function hoursForDate(hours: BusinessHour[], date: Date): BusinessHour | undefined {
  return hours.find((h) => h.day_of_week === date.getDay());
}

export function isClosedOn(hours: BusinessHour[], date: Date): boolean {
  const h = hoursForDate(hours, date);
  return !h || h.is_closed;
}

export function overlaps(aStart: number, aEnd: number, bStart: number, bEnd: number): boolean {
  return aStart < bEnd && bStart < aEnd;
}

/** True when an active appointment already occupies part of [start, start+duration). */
export function isSlotTaken(
  start: number,
  duration: number,
  appointments: Pick<BusyTime, "start_time" | "end_time" | "status">[],
): boolean {
  const end = start + duration;
  return appointments.some(
    (a) =>
      a.status !== "cancelled" &&
      overlaps(start, end, timeToMinutes(a.start_time), timeToMinutes(a.end_time)),
  );
}

/**
 * Start times (every 30 min) where the whole procedure fits inside opening hours,
 * does not overlap the barber's active appointments and is not in the past.
 */
export function availableSlots(params: {
  date: Date;
  hours: BusinessHour[];
  appointments: Pick<BusyTime, "start_time" | "end_time" | "status">[];
  duration: number;
  now?: Date;
  step?: number;
}): string[] {
  const { date, hours, appointments, duration, now = new Date(), step = SLOT_STEP_MINUTES } =
    params;
  const day = hoursForDate(hours, date);
  if (!day || day.is_closed || duration <= 0) return [];

  const open = timeToMinutes(day.open_time);
  const close = timeToMinutes(day.close_time);
  const isToday = toDateKey(date) === toDateKey(now);
  const nowMinutes = now.getHours() * 60 + now.getMinutes();
  if (toDateKey(date) < toDateKey(now)) return [];

  const slots: string[] = [];
  for (let t = open; t + duration <= close; t += step) {
    if (isToday && t <= nowMinutes) continue;
    if (isSlotTaken(t, duration, appointments)) continue;
    slots.push(minutesToTime(t));
  }
  return slots;
}

/** A barber's weekly hours: their own rows, falling back to shop-wide rows (barber_id null). */
export function hoursForBarber(hours: BusinessHour[], barberId: string): BusinessHour[] {
  const own = hours.filter((h) => h.barber_id === barberId);
  const shared = hours.filter(
    (h) => h.barber_id === null && !own.some((o) => o.day_of_week === h.day_of_week),
  );
  return [...own, ...shared];
}

/** One row per weekday (0–6), used to show/edit the shop's hours as a whole. */
export function shopHours(hours: BusinessHour[]): BusinessHour[] {
  const out: BusinessHour[] = [];
  for (let d = 0; d <= 6; d++) {
    const h = hours.find((x) => x.day_of_week === d);
    if (h) out.push(h);
  }
  return out;
}

/** A service with no barber links is offered by every barber. */
export function servicesForBarber<T extends { id: string }>(
  services: T[],
  links: BarberService[],
  barberId: string | undefined,
): T[] {
  if (!barberId) return services;
  return services.filter((s) => {
    const own = links.filter((l) => l.service_id === s.id);
    return own.length === 0 || own.some((l) => l.barber_id === barberId);
  });
}

export function barbersForService(
  serviceId: string,
  links: BarberService[],
  allBarberIds: string[],
): string[] {
  const ids = links.filter((l) => l.service_id === serviceId).map((l) => l.barber_id);
  return ids.length ? ids : allBarberIds;
}

/** The barber's lunch break as a busy period (empty when none is set). */
export function breakAsBusy(breaks: BarberBreak[], barberId: string): BusyTime[] {
  return breaks
    .filter((b) => b.barber_id === barberId)
    .map((b) => ({ start_time: b.start_time, end_time: b.end_time, status: "confirmed" as const }));
}

/**
 * Busy periods used when the admin moves an appointment: the barber's other
 * active appointments that day plus their lunch. The edited one never blocks itself.
 */
export function busyForEdit(params: {
  appointments: Pick<Appointment, "id" | "barber_id" | "start_time" | "end_time" | "status">[];
  breaks: BarberBreak[];
  barberId: string;
  excludeId: string;
}): BusyTime[] {
  const { appointments, breaks, barberId, excludeId } = params;
  return [
    ...appointments
      .filter((a) => a.id !== excludeId && a.barber_id === barberId && a.status !== "cancelled")
      .map((a) => ({ start_time: a.start_time, end_time: a.end_time, status: a.status })),
    ...breakAsBusy(breaks, barberId),
  ];
}
