import { defineConfig } from "vite";
import { tanstackStart } from "@tanstack/react-start/plugin/vite";
import { nitro } from "nitro/vite";
import viteReact from "@vitejs/plugin-react";
import tsconfigPaths from "vite-tsconfig-paths";

export default defineConfig({
  plugins: [
    tanstackStart({
      server: { entry: "server" },
    }),
    nitro({ preset: "cloudflare_module" }),
    viteReact(),
    tsconfigPaths(),
  ],
  build: {
    // esbuild/Rolldown transpiles modern syntax for the iOS 15 Safari generation.
    target: "safari15.3",
  },
});
